%  // ======================================================================
%  //  Jinan University
%  //  @Author: JiZhou CanyangXiong
%  //  @Last Modified time: 2021-03-05      
%  //  @description: ��ÿ�ֱ��ص��ƶ�Ӧ���ز��������м��Ϸ���      
%  // ======================================================================
function [ bits_alloc_sort,bits_alloc_sub_sum] = bits_alloc_position_sum( bits_alloc,SubcarriersNum )
%   Bit corresponding to subcarrier position

bits_alloc_sort = unique(bits_alloc);
 
row=(1:SubcarriersNum);
bits_alloc_1 = [bits_alloc;row];
bits_alloc_1_num = length(bits_alloc_sort);
bits_alloc_sub_sum=cell(1,bits_alloc_1_num); 
for i=1:bits_alloc_1_num
    [~,y] = find(bits_alloc_1(1,:)==bits_alloc_sort(i));
    bits_alloc_sub_sum{i}=bits_alloc_1(2,y);
end

end

